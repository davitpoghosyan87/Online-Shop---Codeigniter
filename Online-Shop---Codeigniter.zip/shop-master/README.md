# Simple Ecommerce
Ecommerce / online shop using PHP 5.5, Codeigniter 3.0, Bootstrap 3.3.5, JQuery 2.1.4, Font Awesome 4.4.0 and some Bootstrap Template


## Demo
http://www.jackstonofficial.com