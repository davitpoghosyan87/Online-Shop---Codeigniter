<?php

/*
 * By Haidar Mar'ie Email = haidarvm@gmail.com MHome
 */
class MHome extends CI_Model {

    function __construct() {
        parent::__construct();
    }
    
    function getAllFeatured(){

        echo 'hai';
    }
    
    function getAllSlides() {

        echo 'hai';
    }
    
    function getHome(){
        echo 'hai';
    }
    
}