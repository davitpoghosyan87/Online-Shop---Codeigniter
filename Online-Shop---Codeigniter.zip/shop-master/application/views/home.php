
	<div class="banner">
		<div class="banner-top">
	         <h2>GoGreenSouvenir</h2>
	         <h3>Apa itu Go Green Souvenir?</h3>
	         <p>Go green souvenir adalah suatu brand usaha yang mengutamakan produk kampanye peduli lingkungan, berupa produk kreatif. Komponen dalam go green souvenir yaitu tanaman, bahan ramah lingkungan, kata-kata ajakan untuk ikut peran serta dalam penghijauan serta bahan penghias lainnya.
	.</span></p>
</div>
	<div class="now">
	         <a class="morebtn" href="product.html">Explore</a>
	         <a class="morebtn at-in" href="single.html">Shop Now</a>
	         <div class="clearfix"> </div>
	         </div>
 	</div>	
 				<div class="clearfix"> </div>	
			</div>
<!---->
		<!---->
		<div class="sap_tabs">
			<div class="container">
			<label class="line"> </label>
			<h2>Latest Products</h2>
						 <div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
						  <ul class="resp-tabs-list">
						  	  <li class="resp-tab-item" aria-controls="tab_item-0" role="tab"><span>Fashion Goggles</span></li>
							  <li class="resp-tab-item" aria-controls="tab_item-1" role="tab"><span>Classic Goggles</span></li>
							  <li class="resp-tab-item" aria-controls="tab_item-2" role="tab"><span>Sun Goggles</span></li>
							  <div class="clearfix"></div>
						  </ul>				  	 
							<div class="resp-tabs-container">
							    <div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
									<div class="tab_img">
									  <div class="img-top simpleCart_shelfItem">
										
					   		  			   <img src="<?php echo img_url();?>pi2.jpg" class="img-responsive" alt=""/>
											
								              <div class="tab_desc">
												 <ul class="round-top">
												 	<li><a href="single.html"><i class="glyphicon glyphicon-search"> </i></a></li>
												 	<li><a href="#"><i class="glyphicon glyphicon-resize-small"> </i></a></li>
												 </ul>
												 
												 	<div class="agency ">
													<div class="agency-left">
														<h6 class="jean">Fashion Goggles</h6>
														<span class="dollor item_price">$50.00</span>
														<div class="clearfix"> </div>
													</div>
													<div class="agency-right">
														<ul class="social">
															<li><a href="#"><i class="item_add"> </i></a></li>
														</ul>
														<ul class="social-in">
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i > </i></a></li>
														</ul>
														<div class="clearfix"> </div>
													</div>
												 </div>
											  </div>
										
										</div>
										<div class="img-top simpleCart_shelfItem">
										  
					   		  			   <img src="<?php echo img_url();?>pi3.jpg" class="img-responsive" alt=""/>
											<div class="tab_desc">
													 <ul class="round-top">
												 	<li><a href="single.html"><i class="glyphicon glyphicon-search"> </i></a></li>
												 	<li><a href="#"><i class="glyphicon glyphicon-resize-small"> </i></a></li>
												 </ul>
												 
												<div class="agency ">
													<div class="agency-left">
														<h6 class="jean">Classic Goggles</h6>
														<span class="dollor item_price">$50.00</span>
														<div class="clearfix"> </div>
													</div>
													<div class="agency-right">
														<ul class="social">
															<li><a href="#"><i class="item_add"> </i></a></li>
														</ul>
														<ul class="social-in">
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i > </i></a></li>
														</ul>
														<div class="clearfix"> </div>
													</div>
												 </div>
											  </div>
											  <div class="col-in">
											  	<p>NEW</p>
											  </div>
											 </div>
											  <div class="img-top simpleCart_shelfItem">
										  
					   		  			   <img src="<?php echo img_url();?>pi4.jpg" class="img-responsive" alt=""/>
											<div class="tab_desc">
															 <ul class="round-top">
												 	<li><a href="single.html"><i class="glyphicon glyphicon-search"> </i></a></li>
												 	<li><a href="#"><i class="glyphicon glyphicon-resize-small"> </i></a></li>
												 </ul>
												 
												 <div class="agency ">
													<div class="agency-left">
														<h6 class="jean">Sun Goggles</h6>
														<span class="dollor item_price">$50.00</span>
														<div class="clearfix"> </div>
													</div>
													<div class="agency-right">
														<ul class="social">
															<li><a href="#"><i class="item_add"> </i></a></li>
														</ul>
														<ul class="social-in">
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i > </i></a></li>
														</ul>
														<div class="clearfix"> </div>
													</div>
												 </div>
											  </div>
											 <div class="col-in col-in-1">
											  	<p>SALE <span>30%</span></p>
											  </div>
											</div>
											<div class="clearfix"></div>
							     </div> 	        					 
						  </div>
							    <div class="tab-1 resp-tab-content" aria-labelledby="tab_item-1">
									<div class="tab_img">
									  <div class="img-top simpleCart_shelfItem">
										
					   		  			   <img src="<?php echo img_url();?>pi9.jpg" class="img-responsive" alt=""/>
											
								              <div class="tab_desc">
												 <ul class="round-top">
												 	<li><a href="single.html"><i class="glyphicon glyphicon-search"> </i></a></li>
												 	<li><a href="#"><i class="glyphicon glyphicon-resize-small"> </i></a></li>
												 </ul>
												 
												 <div class="agency ">
													<div class="agency-left">
														<h6 class="jean">Fashion Goggles</h6>
														<span class="dollor item_price">$50.00</span>
														<div class="clearfix"> </div>
													</div>
													<div class="agency-right">
														<ul class="social">
															<li><a href="#"><i class="item_add"> </i></a></li>
															<li><a href="#"><i class="text"> </i></a></li>
														</ul>
														<ul class="social-in">
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i > </i></a></li>
														</ul>
														<div class="clearfix"> </div>
													</div>
												 </div>
											  </div>
										</div>
										<div class="img-top simpleCart_shelfItem">
					   		  			   <img src="<?php echo img_url();?>pi8.jpg" class="img-responsive" alt=""/>
											<div class="tab_desc">
												 <ul class="round-top">
												 	<li><a href="single.html"><i class="glyphicon glyphicon-search"> </i></a></li>
												 	<li><a href="#"><i class="glyphicon glyphicon-resize-small"> </i></a></li>
												 </ul>
												 <div class="agency ">
													<div class="agency-left">
														<h6 class="jean">Classic Goggles</h6>
														<span class="dollor item_price">$50.00</span>
														<div class="clearfix"> </div>
													</div>
													<div class="agency-right">
														<ul class="social">
															<li><a href="#"><i class="item_add"> </i></a></li>
															<li><a href="#"><i class="text"> </i></a></li>
														</ul>
														<ul class="social-in">
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i > </i></a></li>
														</ul>
														<div class="clearfix"> </div>
													</div>
												 </div>
											  </div>
											  <div class="col-in">
											  	<p>NEW</p>
											  </div>
											 </div>
											  <div class="img-top simpleCart_shelfItem">
					   		  			   <img src="<?php echo img_url();?>pi10.jpg" class="img-responsive" alt=""/>
											<div class="tab_desc">
												 <ul class="round-top">
												 	<li><a href="single.html"><i class="glyphicon glyphicon-search"> </i></a></li>
												 	<li><a href="#"><i class="glyphicon glyphicon-resize-small"> </i></a></li>
												 </ul>
												 <div class="agency ">
													<div class="agency-left">
														<h6 class="jean">Sun Goggles</h6>
														<span class="dollor item_price">$50.00</span>
														<div class="clearfix"> </div>
													</div>
													<div class="agency-right">
														<ul class="social">
															<li><a href="#"><i class="item_add"> </i></a></li>
															<li><a href="#"><i class="text"> </i></a></li>
														</ul>
														<ul class="social-in">
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i > </i></a></li>
														</ul>
														<div class="clearfix"> </div>
													</div>
												 </div>
											  </div>
											 <div class="col-in col-in-1">
											  	<p>SALE <span>30%</span></p>
											  </div>
											</div>
											<div class="clearfix"></div>
							     </div>						 
						  </div>
						    <div class="tab-1 resp-tab-content" aria-labelledby="tab_item-2">
									<div class="tab_img">
									  <div class="img-top simpleCart_shelfItem">
										
					   		  			   <img src="<?php echo img_url();?>pi5.jpg" class="img-responsive" alt=""/>
											
								              <div class="tab_desc">
												 <ul class="round-top">
												 	<li><a href="single.html"><i class="glyphicon glyphicon-search"> </i></a></li>
												 	<li><a href="#"><i class="glyphicon glyphicon-resize-small"> </i></a></li>
												 </ul>
												 
												 <div class="agency ">
													<div class="agency-left">
														<h6 class="jean">Fashion Goggles</h6>
														<span class="dollor item_price">$50.00</span>
														<div class="clearfix"> </div>
													</div>
													<div class="agency-right">
														<ul class="social">
															<li><a href="#"><i class="item_add"> </i></a></li>
															<li><a href="#"><i class="text"> </i></a></li>
														</ul>
														<ul class="social-in">
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i > </i></a></li>
														</ul>
														<div class="clearfix"> </div>
													</div>
												 </div>
											  </div>
										</div>
										<div class="img-top simpleCart_shelfItem">
										  
					   		  			   <img src="<?php echo img_url();?>pi6.jpg" class="img-responsive" alt=""/>
											<div class="tab_desc">
												 <ul class="round-top">
												 	<li><a href="single.html"><i class="glyphicon glyphicon-search"> </i></a></li>
												 	<li><a href="#"><i class="glyphicon glyphicon-resize-small"> </i></a></li>
												 </ul>
												 	<div class="agency ">
													<div class="agency-left">
														<h6 class="jean">Classic Goggles</h6>
														<span class="dollor item_price">$50.00</span>
														<div class="clearfix"> </div>
													</div>
													<div class="agency-right">
														<ul class="social">
															<li><a href="#"><i class="item_add"> </i></a></li>
															<li><a href="#"><i class="text"> </i></a></li>
														</ul>
														<ul class="social-in">
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i > </i></a></li>
														</ul>
														<div class="clearfix"> </div>
													</div>
												 </div>
											  </div>
											  <div class="col-in">
											  	<p>NEW</p>
											  </div>
											 </div>
											  <div class="img-top simpleCart_shelfItem">
										  
					   		  			   <img src="<?php echo img_url();?>pi7.jpg" class="img-responsive" alt=""/>
											<div class="tab_desc">
												 <ul class="round-top">
												 	<li><a href="single.html"><i class="glyphicon glyphicon-search"> </i></a></li>
												 	<li><a href="#"><i class="glyphicon glyphicon-resize-small"> </i></a></li>
												 </ul>
												 
												 	<div class="agency ">
													<div class="agency-left">
														<h6 class="jean">Sun Goggles</h6>
														<span class="dollor item_price">$50.00</span>
														<div class="clearfix"> </div>
													</div>
													<div class="agency-right">
														<ul class="social">
															<li><a href="#"><i class="item_add"> </i></a></li>
															<li><a href="#"><i class="text"> </i></a></li>
														</ul>
														<ul class="social-in">
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i> </i></a></li>
															<li><a href="#"><i > </i></a></li>
															<li><a href="#"><i > </i></a></li>
														</ul>
														<div class="clearfix"> </div>
													</div>
												 </div>
											  </div>
											 <div class="col-in col-in-1">
											  	<p>SALE <span>30%</span></p>
											  </div>
											</div>
											<div class="clearfix"></div>
							     </div>	 	        					 
						  </div>		
                  </div>
          </div>
         </div>
	</div>
	<!--start-shoes--> 
	<div class="goggles"> 
		<div class="container"> 
			<h2>Latest Goggles</h2>
			<div class="product-one">
				<?php foreach($products as $product) {?>
				<div class="col-md-3 product-left"> 
					<div class="p-one simpleCart_shelfItem">							
							<a href="<?php echo site_url().'product/detail/'.$product->product_id;?>">
								<img src="<?php echo prod_thumb_url().$product->image_id.$product->ext;?>" alt="" />
								<div class="mask">
									<span>Quick View</span>
								</div>
							</a>
						<h4>Aenean placerat</h4>
						<p><a class="item_add" href="#"><i></i> <span class=" item_price">$12</span></a></p>
					
					</div>
				</div>
				<?php } ?>
				<div class="clearfix"> </div>
			</div>
			<div class="product-one">
				<div class="col-md-3 product-left"> 
					<div class="p-one simpleCart_shelfItem">
						
						<a href="single.html">
								<img src="<?php echo img_url();?>n5.jpg" alt="" />
								<div class="mask">
									<span>Quick View</span>
								</div>
							</a>
						<h4>Aenean placerat</h4>
						<p><a class="item_add" href="#"><i></i> <span class=" item_price">$18</span></a></p>
						
					</div>
				</div>
				<div class="col-md-3 product-left"> 
					<div class="p-one simpleCart_shelfItem">
						
						<a href="single.html">
								<img src="<?php echo img_url();?>n6.jpg" alt="" />
								<div class="mask">
									<span>Quick View</span>
								</div>
							</a>
						<h4>Aenean placerat</h4>
						<p><a class="item_add" href="#"><i></i> <span class=" item_price">$19</span></a></p>
						
					</div>
				</div>
				<div class="col-md-3 product-left"> 
					<div class="p-one simpleCart_shelfItem">
						
						<a href="single.html">
								<img src="<?php echo img_url();?>n7.jpg" alt="" />
								<div class="mask">
									<span>Quick View</span>
								</div>
							</a>
						<h4>Aenean placerat</h4>
						<p><a class="item_add" href="#"><i></i> <span class=" item_price">$21</span></a></p>
						
					</div>
				</div>
				<div class="col-md-3 product-left"> 
					<div class="p-one simpleCart_shelfItem">
						
						<a href="single.html">
								<img src="<?php echo img_url();?>n8.jpg" alt="" />
								<div class="mask">
									<span>Quick View</span>
								</div>
							</a>
						<h4>Aenean placerat</h4>
						<p><a class="item_add" href="#"><i></i> <span class=" item_price">$40</span></a></p>
						
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!--end-shoes-->
	<!---->
	