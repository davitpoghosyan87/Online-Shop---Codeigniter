
<!--   Content top
–––––––––––––––––––––––––––––––––––––––––––––––––– -->
<div class="content">
  <div class="container">
  	<div class="row">
  		<div class="twelve columns"><!-- Top info -->
  			<div class="infotop">
  				<p>Deftly tailored from very fine woven egyptian cotton, these shirts are smooth to the touch, though still maintain their elegant shape. Essential pieces that easily cross from the week into the weekend.</p>
  			</div>
  		</div><!-- End Top info -->
  	</div>
  </div>
</div>

<!--   Content produk
–––––––––––––––––––––––––––––––––––––––––––––––––– -->
<div class="content">
  <div class="container">
		<div class="row">
			<div class="three columns" style="margin-left: 0;">  
			    <a class="tab_link" title="#p1a" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bnew.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/1.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
			<div class="three columns">  
			    <a class="tab_link" title="#p1b" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bnew.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/2.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
			<div class="three columns">  
			    <a class="tab_link" title="#p1c" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bbin.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/3.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
			<div class="three columns">  
			    <a class="tab_link" title="#p1d" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bbin.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/4.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
            <div class="three columns" style="margin-left: 0;">  
			    <a class="tab_link" title="#p1a" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bnew.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/1.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
			<div class="three columns">  
			    <a class="tab_link" title="#p1b" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bnew.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/2.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
			<div class="three columns">  
			    <a class="tab_link" title="#p1c" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bbin.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/3.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
			<div class="three columns">  
			    <a class="tab_link" title="#p1d" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bbin.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/4.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
            <div class="three columns" style="margin-left: 0;">  
			    <a class="tab_link" title="#p1a" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bnew.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/1.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
			<div class="three columns">  
			    <a class="tab_link" title="#p1b" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bnew.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/2.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
			<div class="three columns">  
			    <a class="tab_link" title="#p1c" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bbin.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/3.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
			<div class="three columns">  
			    <a class="tab_link" title="#p1d" href="#">
			    	<div class="produk">
	  					<div class="barang"><img src="<?php echo base_url();?>assets/img/produk/bbin.png"/></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo base_url();?>assets/img/produk/4.jpg"/></div>
						<div class="hoverproduk">
							<a href="<?php echo site_url();?>product/test_detail"><div class="hpnam"><img src="<?php echo base_url();?>assets/img/produk/hp4.png" /></div></a>
						</div>
					</div>
			    </a>
			</div>
		</div>
		
	</div><!-- End container -->
</div><!-- End home info -->

<script>
	$(document).ready(function(){
		$('.tab_link').tab();
		$('#slider1').slide();
		$('.item').accordion();
	});
</script>
<?php  /* foreach($product as $row) {?>
			<div class="three columns">  
			    <a class="" title="#p1a" href="<?php echo site_url().'product/detail/'.$row->product_id;?>">
			    	<div class="produk">
	  					<div class="barang"></div>
						<div class="gmbproduk"><img class="gmbproduk" src="<?php echo prod_small_url().$row->product_id.'.'.$row->ext?>"/></div>
						<div class="hoverproduk">
							<div class="hpnam"><img src="<?php echo prod_small_url().$row->product_id.'.'.$row->ext?>" /></div>
						</div>
					</div>
			    </a>
			</div>
			<?php } */ ?>