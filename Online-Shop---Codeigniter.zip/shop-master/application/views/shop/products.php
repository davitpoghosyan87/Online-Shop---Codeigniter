<?php
print_r($products);