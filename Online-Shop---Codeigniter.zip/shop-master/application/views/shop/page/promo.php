<div class="content">
  <div class="container">
  	<div class="row"><!-- Image of produk home -->
  		<div class="four columns">
  			<div class="produk">
				<div class="gmbproduk"><img class="gmbproduk" src="<?php echo img_url()?>xmas.png"/></div>
			</div>
  		</div>
  		<div class="four columns">
  			<div class="twelve columns">
  				<div class="produk">
					<div class="gmbproduk"><img class="gmbproduk" src="<?php echo img_url()?>tees.png"/></div>
					<div class="hoverproduk">
						<div class="hpnam"><a href="<?php echo site_url()?>product/tees"><img src="<?php echo img_url()?>produk/hp1.png" /></a></div>
					</div>
				</div>
  			</div>
  			<div class="row"></div>
  		</div>
  		<div class="four columns">
  			<div class="twelve columns">
  				<div class="produk">
					<div class="gmbproduk"><img class="gmbproduk" src="<?php echo img_url()?>jacket.png"/></div>
					<div class="hoverproduk">
						<div class="hpnam"><img src="<?php echo img_url()?>produk/hp2.png" /></div>
					</div>
				</div>
  			</div>
  			<div class="row"></div>
  			<div class="twelve columns">
  				<div class="produk">
					<div class="gmbproduk"><img class="gmbproduk" src="<?php echo img_url()?>jeans.png"/></div>
					<div class="hoverproduk">
						<div class="hpnam"><img src="<?php echo img_url()?>produk/hp2.png" /></div>
					</div>
				</div>
  			</div>
  		</div>
		<div class="eight columns" style="margin-top: 3%;">	
			<div class="produk">
				<div class="gmbproduk"><img class="gmbproduk" src="<?php echo img_url()?>lucky_draw.png"/></div>
				<div class="hoverproduk">
					<div class="hpnam"><img src="<?php echo img_url()?>produk/hp3.png" /></div>
				</div>
			</div>
		</div>
  	</div><!-- End image of produk home -->
  </div>
</div>