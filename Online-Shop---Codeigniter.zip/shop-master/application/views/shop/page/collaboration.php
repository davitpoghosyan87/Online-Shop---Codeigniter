<div class="content">
  <div class="container">
  	<div class="row"><!-- Image of produk home -->
  		<div class="twelve columns artikel">
  			<center><h2>The Ring Trade BASKO x JACKSTON</h2></center>
  			<p>By : Basko</p>
  			<p>December 2014</p>
  			<br />
  			<center><img width="100%" src="<?php echo img_url()?>artikel/1.jpg" /></center>
  			<br />
  			<p>More of Culture evolves from lifestyle, a new breed emerges every time it claches. Jackston has to be one of those opposed to simply just a brand or fashion label. insipred by color, culture, roots & the basic foundation of happiness, we dwell in the Irie felling & inhale the richest sativa to embrace & be part of the culture clash “STAG blends the best of many unique elements and ideas into an emporium of essentials for leading the life of a modern gentleman. We include style icons like Steve McQueen, James Dean, Keith Richards, and Willie Nelson into that definition.” - STAG website. <br/>
  			We couldn’t have put a description together any better.<br/>
  			Not only have we been huge fans of this Austin-based powerhouse since they came onto the retail scene, but we’ve been proud to have them part of the RP family of stockists since our beginning. 2010 to be. Owners Steve Schuck and Don Weir have created a menswear mecca for discerning clients. These are the guys that call on them for the tried and true brands that they collect but look to them for up-and-coming lines that they are able to discover for the first time and weave into their closets as well.</p>
  			<br />
  			<center>
	  			<img width="30%" src="<?php echo img_url()?>artikel/2.jpg" />
	  			<img width="30%" src="<?php echo img_url()?>artikel/3.jpg" />
	  			<img width="30%" src="<?php echo img_url()?>artikel/4.jpg" />
  			</center>
  			<br />
  			<p>Our Creative Director, Joe Tornatzky and myself recently took a drive up to Abbot Kinney in Venice and spent some time with the very welcoming staff of Stag’s West Coast flagship location. Every piece in the store is perfectly placed, the product/brand mix and merchandising is impeccably curated and the store build-out is a visual dream. Even with all that...the store is extremely approachable, inviting and just a comfortable place that exudes the vibe of "come hang out with us and have a beer." (Which we most definitely did!).</p>
  			<br />
  			<center><img width="100%" src="<?php echo img_url()?>artikel/6.jpg" /></center>
  		</div>
  	</div><!-- End image of produk home -->
  </div>
</div>