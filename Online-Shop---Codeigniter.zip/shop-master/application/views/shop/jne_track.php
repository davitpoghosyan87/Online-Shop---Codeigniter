Lacak resi <b>JNE</b> di sini<br />
<form action="http://www.jne.co.id/index.php" method="get" name="input" target="_new2">
<input name="mib" value="tracking.detail" type="hidden" />
 <input name="awb" size="14" style="border:1px solid #b2b2b2;margin-bottom:-20px;width:120px;padding:5px;border-radius:0px;" type="text" />
<input value="Cek" style="border:1px solid #DC3F3F;padding:4px;border-radius:0px;font-weight:bold;background:#EE5858;color:#fff" type="submit" /></form>
Lacak resi <b>TIKI</b> di sini:
<br />
<form method="post" action="http://www.tiki-online.com/tracking/track_single" name="input" target="_blank"><input id="TxtCon" name="TxtCon" size="14" style="border:1px solid #b2b2b2;margin-bottom:-20px;width:120px;padding:5px;border-radius:0px;" type="text" />
<input id="button" name="button" value="Cek" style="border:1px solid #DC3F3F;padding:4px;border-radius:0px;font-weight:bold;background:#EE5858;color:#fff" type="submit" /></form>
Lacak resi <b>POS Indonesia</b>:
<form method="get" action="http://www.posindonesia.co.id/home/modules/mod_search/tmpl/libs/lacakk1121m4np05.php" name="input" target="_blank"><input name="barcode" size="14" style="border:1px solid #b2b2b2;margin-bottom:-20px;width:120px;padding:5px;border-radius:0px;" type="text" />
<input value="Cek" style="border:1px solid #DC3F3F;padding:4px;border-radius:0px;font-weight:bold;background:#EE5858;color:#fff" type="submit" /></form>